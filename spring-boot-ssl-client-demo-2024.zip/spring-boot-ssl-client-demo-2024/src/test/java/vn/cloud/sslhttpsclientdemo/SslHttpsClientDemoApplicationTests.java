package vn.cloud.sslhttpsclientdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SslHttpsClientDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
