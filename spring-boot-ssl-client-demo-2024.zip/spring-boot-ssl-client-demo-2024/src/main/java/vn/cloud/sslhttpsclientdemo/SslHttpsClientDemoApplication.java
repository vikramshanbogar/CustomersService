package vn.cloud.sslhttpsclientdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.web.client.RestClientSsl;
import org.springframework.boot.ssl.SslBundles;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class SslHttpsClientDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslHttpsClientDemoApplication.class, args);
	}

	@Bean
	RestClient restClient(RestClient.Builder builder, RestClientSsl ssl) {
		return builder
				.baseUrl("https://localhost")
				.apply(ssl.fromBundle("client"))
				.build();
	}

	@Bean
	RestTemplate restTemplate(RestTemplateBuilder builder, SslBundles sslBundles) {
		return builder
				.rootUri("https://localhost")
				.setSslBundle(sslBundles.getBundle("client"))
				.build();
	}
}
