# This repo is used for this [youtube video](https://www.youtube.com/watch?v=sdmIuj81LnY)

#### RestTemplate/RestClient Calls to a Self-Signed HTTPS Spring Boot + Enable SSL Client Authentication
https://www.youtube.com/watch?v=sdmIuj81LnY